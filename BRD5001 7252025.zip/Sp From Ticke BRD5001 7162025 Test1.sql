USE [BOfA_customer]
GO

/****** Object:  StoredProcedure [dbo].[spSavingToCreditCampaign]    Script Date: 7/16/2025 11:41:43 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

Create Procedure [dbo].[spSavingToCreditCampaign]
As
Begin
SET NOCOUNT ON

/**** Stored Procedure Based on Business Requirements Documents (BRD) CaseID: 5001 ****/

/**** 
Procedure Name: spSavingToCreditCampaign

Purpose: Loading lead customers to Campaign List and Campaign Histiry tables.

Description: Clients that have Saving Account but no Credit Card Account with the bank are encouraged to 
			 open Credit Card  Account throgh a campaign. The objective of this stored procedure is to 
			 generate leads that meet the requirements BRD CaseID 5001.

Execusion Time: Less than a minute.

Revision History
Date				Intials					Description
==============		================		================
7/16/2025			GA						Initial Version

****/

Insert Into Population1 ([ID]
,[AcctNo]
,[Scrub]
,[first_name] 
,[last_name]
,[Email_Address]
,[Detail1]
,[Detail3]
,[Address1]
,[Address2]
,[AddressCity]
,[AddressZip]
,[OpenDate]
,[Channel]
)

Select AP.[ID]
,AP.[AcctNo]
,'Available'
,AP.[first_name] 
,AP.[last_name]
,AP.[email]
,AP.[DateOFBirth]	--Detail1
,AF.[Assets]		--These Assets are considered as  the Saving Account Balance as Detail3
,AP.[AddressLine1]
,AP.[AddressLine12]
,AP.[AddressCity]
,AP.[AddressZipCd]
,AP.OpenDate
,AP.[Channel]
	FROM [BOfA_customer].[dbo].[Accounts_Profile] AP
	Inner Join [dbo].[Accounts_Financial] AF ON 
	AP.[AcctNo]= AF.[AcctNo]
	Where AP.[Channel] in ('Saving') and AP.[Channel]  Not In ('Credit Card')  /* Clients who have 
	a saving account but not a credit card account requirement*/
	 
	Update Population1
    Set Detail2 = DateDiff(Year, OpenDate, GetDate()) -
	Case 
		When DateAdd(Year,DateDiff(Year, OpenDate, GetDate()), OpenDate) > GetDate()
		Then 1 Else 0
	End; --Age of the Saving Account as Detail2
		
	
	Update Population1
	Set Scrub = 'Less than 500'
	Where Detail3 <500  --Accounts that have less than or equal to 500 in saving

	Update Population1
	Set Scrub = 'DSCD'
	Where [AcctNo] in (Select [AcctNo] From BOfA_DSCD_Customers) -- Primary account holder is deceased
 
	Update Population1
	Set Scrub = 'HazardHittedArea'
	Where [AddressZip] in (Select [HZIP] From [dbo].[BOfA_HZIP]) /* Household has a zip 
	code in a FEMA disaster area*/

	Update Population1
	Set Scrub = 'Money Laundering'
	Where [AcctNo] in (Select [AcctNo] From [dbo].[BOfA_AML_Customers]) /* Money Laundering 
	Alert present */

	Update Population1
	Set Scrub = 'Age younger than 25'
	Where (DateDiff(Year, Detail1, GetDate()) -
	Case 
		When DateAdd(Year,DateDiff(Year, Detail1, GetDate()), Detail1) > GetDate()
		Then 1 Else 0
	End) < 25 --Clients that are younger than 25 years


Insert Into [dbo].[BoFA_CampaignList] (ListDate
,[AcctNo]
,[Campaign_Name]
,[Detail1]
,[Detail2]
,[Detail3]
,[Scrub]
,[Email_Address]
,[First_Name]
,[Last_Name]
,[Address1]
,[Address2]
,[AddressCity]
,[AddressZip]
)
 
Select GetDate()
,[AcctNo]
,'SavingToCredit_girma'
,[Detail1]
,[Detail2]
,[Detail3]
,[Scrub]
,[Email_Address]
,[First_Name]
,[Last_Name]
,[Address1]
,[Address2]
,[AddressCity]
,[AddressZip]
	From Population1
	Where Scrub Not In ('Less than 500','DSCD','HazardHittedArea','Money Laundering',
	'Age younger than 25') /**Campaign List with the BRD requirements **/
	

Insert Into [dbo].[BOfA_CPGN_HISTORY] (ListDate
,[Campaignname]
,[Channel]
,[Acctno]
,[EmailAddress]
,[AcctTypeCd]
,[FirstName]
,[LastName]
,[Fullname]
,[Address1]
,[Address2]
,[City]
,[Zip]
,[Detail1]
,[Detail2]
,[Detail3]
,[Scrub]
) 

Select GetDate()
,'SavingToCredit_girma'
,AP.[Channel]
,AP.[AcctNo]
,AP.[email]
,AP.[AcctTypeCd]
,AP.[first_name]
,AP.[last_name]
,'"[FirstName]" +' '+ "[LastName]"'
,AP.[AddressLine1]
,AP.[AddressLine12]
,AP.[AddressCity]
,AP.[AddressZipCd]
,P.[Detail1]
,P.[Detail2]
,P.[Detail3]
,P.[Scrub]
	FROM Population1 P
	Join [dbo].[Accounts_Profile] AP ON 
	P.[AcctNo]= AP.[AcctNo]
	Where AP.[Channel] = 'Saving' 
END /**** Campaign History List */ 
GO


