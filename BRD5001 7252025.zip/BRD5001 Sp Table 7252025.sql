USE [BOfA_customer]
GO

/****** Object:  Table [dbo].[Population1]    Script Date: 7/16/2025 11:45:12 PM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[Population1](
	[ID] [varchar](50) NULL,
	[AcctNo] [varchar](25) NULL,
	[Scrub] [varchar](100) NULL,
	[Email_Address] [varchar](100) NULL,
	[First_Name] [varchar](50) NULL,
	[Last_Name] [varchar](50) NULL,
	[Name_prefix] [varchar](10) NULL,
	[MidInitial] [varchar](5) NULL,
	[NameSuffix] [varchar](10) NULL,
	[Detail1] [datetime] NULL,
	[Detail2] [varchar](30) NULL,
	[Detail3] [decimal](10, 2) NULL,
	[Detail4] [varchar](30) NULL,
	[Address1] [varchar](50) NULL,
	[Address2] [varchar](50) NULL,
	[AddressCity] [varchar](25) NULL,
	[AddressState] [varchar](5) NULL,
	[AddressZip] [varchar](10) NULL,
	[DateOfBirth] [datetime] NULL,
	[OpenDate] [datetime] NULL,
	[Assets] [decimal](10, 2) NULL,
	[Channel] [varchar](50) NULL
) ON [PRIMARY]
GO


